= XTE J1759-220

see also the XRT lc