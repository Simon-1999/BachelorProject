XMMSL1 J171900.4-353217 = XTE J1719-356 a faint source from RXTE bulge scans?

see ATEl 2615
see XRT folder for lc