Extreem heldere ster (JHK~2 mag) op deze positie?

* 36 Oph 

vreemd, een redelijk heldere X-ray uitbarsting van enkele weken in 2008, lijkt me niet mogelijk dat van K sterren te krijgen...